<?php
require_once 'Reptil.php';
class Cobra extends Reptil {
    
}
