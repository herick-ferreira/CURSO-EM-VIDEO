<?php
require_once 'Reptil.php';
class Tartaruga extends Reptil {
    public function locomover(){
        echo "<p>Andando Devagaaaaaar</p>";
    }
}
