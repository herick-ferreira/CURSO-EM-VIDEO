<?php
require_once 'Peixe.php';
class GoldFish extends Peixe {
    
}
