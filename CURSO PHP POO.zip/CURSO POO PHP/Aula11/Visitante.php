<?php
require_once 'Pessoa.php';
class Visitante extends Pessoa {
    
}
