<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="_css/estilo.css"/>
  <meta charset="UTF-8"/>
  <title>Curso de PHP - CursoemVideo.com</title>
</head>
<body>
<div>
    <?php
        $nome = "gustvo guanbara";
        $nome2 = ucwords($nome);
        echo "Seu nome é $nome2";
    ?>
</div>
</body>
</html>
 