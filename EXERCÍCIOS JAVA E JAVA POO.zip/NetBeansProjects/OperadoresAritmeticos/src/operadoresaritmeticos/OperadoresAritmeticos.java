/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operadoresaritmeticos;

/**
 *
 * @author HericK
 */
public class OperadoresAritmeticos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*int n1 = 3;
        int n2 = 5;
        float m = (n1+n2)/2;
        System.out.println("A média é igual a " + m);*/
        
        /*int numero = 5;
        numero++;
        System.out.println(numero);*/
        
        /*int numero = 5;
        int valor = 5 + numero++;
        System.out.println(valor);*/
        
        /*int numero = 5;
        int valor = 5 + ++numero;
        System.out.println(valor);
        System.out.println(numero);*/
        
        /*int numero = 5;
        int valor = 5 + numero++;
        System.out.println(valor);
        System.out.println(numero);*/
        
        /*int numero = 10;
        int valor = 4 + numero--;
        System.out.println(valor);
        System.out.println(numero);*/
        
        /*int x = 4;
        x += 2;
        System.out.println(x);*/
        
        /*float v = 8.3f;
        int ar = (int)Math.round(v);
        System.out.println(ar);*/
        
        double ale = Math.random();
        int n = (int)(15 + ale * (50-15));
        System.out.println(n);
        
                
    }
    
}
