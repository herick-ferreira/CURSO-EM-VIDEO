package aula12_poo;
public class Arara extends Ave {
    
}
