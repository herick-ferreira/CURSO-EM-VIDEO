package aula12_poo;
public class GoldFish extends Peixe {
    
}
