package aula12_poo;
public class Tartaruga extends Reptil {
    @Override
    public void locomover() {
        System.out.println("Beeeem Devagar");
    }
}
