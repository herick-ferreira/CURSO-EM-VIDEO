package aula12_poo;
public class Cobra extends Reptil {
    
}
