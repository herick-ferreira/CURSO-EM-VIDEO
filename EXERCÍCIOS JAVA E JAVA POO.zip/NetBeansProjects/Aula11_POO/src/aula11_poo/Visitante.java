package aula11_poo;
public class Visitante extends Pessoa {
    
}
