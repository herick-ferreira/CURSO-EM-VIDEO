package aula14_e_aula_15_poo_projetoyoutube;
public interface AcoesVideo {
    public void play();
    public void pause();
    public void like();
}
