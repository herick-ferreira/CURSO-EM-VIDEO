package aula13;
public abstract class Animal {
    protected float peso;
    protected int idade;
    protected int memebros;
    
    public abstract void emitirSom();
}
