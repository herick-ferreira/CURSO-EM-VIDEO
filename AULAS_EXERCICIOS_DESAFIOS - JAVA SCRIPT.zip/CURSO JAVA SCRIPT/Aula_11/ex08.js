var vel = 12
console.log(`A velocidade do seu carro é ${vel} Km/h`)
if (vel > 60){//Condição Simples
    console.log('Você ultrapassou a velocidade permitida. MULTADO!')
}
console.log('Dirija sempre usando cinto de segurança!')