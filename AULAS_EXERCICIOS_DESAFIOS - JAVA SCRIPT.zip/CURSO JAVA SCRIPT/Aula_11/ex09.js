var pais = 'Brasil'
console.log(`Vivendo no ${pais} `)
if (pais == 'Brasil'){
    console.log('Você é Brasileiro!')
}else {
    console.log('Você é Estrangeiro!')
}