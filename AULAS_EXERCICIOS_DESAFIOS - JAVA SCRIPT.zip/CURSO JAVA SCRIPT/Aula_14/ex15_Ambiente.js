var c = 1
for (var c = 1; c<= 10;c++){
    console.log(`Passo ${c}`)
}