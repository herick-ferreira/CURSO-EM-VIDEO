let num = [5,8,2,3]
num.sort()
num.push(1)
//num[3] = 6
console.log(`O vetor tem ${num.length} posições`)
console.log(`O primeiro valor do vetor é ${num[0]}`)


