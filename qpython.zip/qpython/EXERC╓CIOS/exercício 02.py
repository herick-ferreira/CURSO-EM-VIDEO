nome = (input ('Qual é o seu nome?'))
print('seja bem vindo, {}!'.format(nome))
