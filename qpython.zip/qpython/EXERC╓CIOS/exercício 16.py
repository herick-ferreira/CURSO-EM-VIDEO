'''from math import trunc
n = float(input('Digite um valor:'))
print ('O valor digitado foi {} e a sua porção inteira é {}'.format(n,trunc(n)))'''
	
n = float(input('Digite um valor:'))
print ('O valor digitado foi {} e a sua porção inteira é {}'.format(n, int(n)))


