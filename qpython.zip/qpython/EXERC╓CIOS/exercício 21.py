import pygame
pygame.init()
pygame.mixer.music.load('exercicio19mp3')
pygame.mixer.music.play()
pygame.event.wait()