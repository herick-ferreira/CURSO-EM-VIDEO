c = float(input('Informe a temperatura em ⁰C:'))
f = 9* c /5 + 32
print ('A temperatura em {}⁰C corresponde a {}⁰F!'.format(c, f))