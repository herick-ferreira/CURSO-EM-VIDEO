def titulo(txt):
   print ('›'*(len(txt)+4))
   print(f'  {txt}')
   print ('›'*(len(txt)+4))
titulo ('CURSO EM VÍDEO')
    