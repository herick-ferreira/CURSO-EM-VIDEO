primeiro = int(input('Primeiro número:'))
segundo = int(input('Segundo número:'))
if primeiro > segundo:
      print('O PRIMEIRO valor é maior')
elif segundo > primeiro:
      print ('O SEGUNDO valor é maior')
else:
      print ('Os dois valores são IGUAIS')
