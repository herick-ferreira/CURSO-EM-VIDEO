n1 = float(input('Primeira nota do aluno:'))
n2 = float(input('Segunda nota do aluno:'))
print ('A média é igual a {:.1f}'.format ((n1+n2)/2))