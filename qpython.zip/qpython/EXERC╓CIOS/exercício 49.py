n = int(input ('Digite  número para ver sua tabuada: '))
for c in range (1,11):
     print('{} X {:2} = {}'.format(n, c, n*c))
     