#from math import sqrt
n = int(input('Digite um número:'))
print (' o triplo de {} é igual a {}, a raiz de {} é igual a {}, o dobro de {} é igual a {}' .format (n, (n*3), n, (n**(1/2)), n, (n*2)))