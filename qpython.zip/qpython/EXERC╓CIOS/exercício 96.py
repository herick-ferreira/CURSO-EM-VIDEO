def area (larg,compr):
    a = larg * compr     
    print(f'A área de um terreno {larg} X {compr} é de {a}m².')


print('          CONTROLE DE TERRENOS')
print('-'*41)
l = float(input('LARGURA (m): '))
c = float(input('COMPRIMENTO (m): '))
area(l,c)    

      

