n = int(input('Digite um número:'))
#a = n - 1
#s = n + 1
print ('analisando o valor {}, seu antecessor é {} e seu sucessor é {}'.format (n,(n - 1),(n + 1)))