for c in range (1+1, 50 + 1, 2):
     print(c, end=' ')