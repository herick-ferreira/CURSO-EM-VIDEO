velocidade = float(input('Qual é a velocidade do carro?'))
multa = 7*(velocidade -80)
if velocidade >=80:
    print('Multado! Você excedeu o limite permitido que é de 80km/h')
    print ('Você deve pagar uma multa de R$ {:.2f}!'.format(multa))
print ('Tenha um bom dia dirija com segurança!')

    

        
