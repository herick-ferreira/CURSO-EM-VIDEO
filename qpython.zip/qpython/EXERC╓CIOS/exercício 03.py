n1 = int (input ('Digite um valor:'))
n2 = int (input ('Digite Outro:'))
s = n1 + n2
print ('a soma entre {0} e {1} vale {2}'.format (n1, n2, s))