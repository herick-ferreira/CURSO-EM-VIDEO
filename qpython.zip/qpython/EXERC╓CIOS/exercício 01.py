msg = 'Olá Mundo!'
print (msg)

p = 0
s = 0
i = 0

for c in range (p,s+1,i):
    p = int(input('digite o primeiro valor: '))
    s = int(input('digite o segundo valor: '))
    i =	int(input('digite o incremento: '))
    if (p>s):
       i = i*(-1)
       print(c)
    else:
        print(c)

      

