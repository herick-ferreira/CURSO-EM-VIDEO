import androidhelper

droid = androidhelper.Android()
droid.cameraInteractiveCapturePicture('/sdcard/qpython.jpg')
