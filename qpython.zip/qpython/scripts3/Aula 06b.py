#-*-coding:utf8;-*-
#qpy:console

print "This is console module"
