import androidhelper
droid = androidhelper.Android()
droid.makeToast('Hello, Android!')
print('Hello world!')
