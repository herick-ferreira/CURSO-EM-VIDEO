"""
países=  ('Alemanha', 'Itália')
print (países[0], países [-1])
"""
"""
num = [8,2,4,2,5,2]
print(num.count(2))
"""
"""
num = [6,2,1,4,3]
num.sort(reverse=True)
print(num)
"""
"""
num = [2,8,4,7]
num.pop()
num.insert(1,3)
num.append(6)
print(num)
"""
"""
pontos = (1,2,5,4,3)
print(sorted(pontos))
"""
val = list(range(1,5))
print(val)