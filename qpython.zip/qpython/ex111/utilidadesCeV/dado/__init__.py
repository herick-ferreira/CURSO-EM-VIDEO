def leiadinheiro(valor):
       print('Erro')