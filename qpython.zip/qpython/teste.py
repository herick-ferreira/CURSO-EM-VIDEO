import pip
pip.main(['install','pygame'])

