nome = input ('Qual é o seu nome?')
print ('É um grande prazer te conhecer', nome)