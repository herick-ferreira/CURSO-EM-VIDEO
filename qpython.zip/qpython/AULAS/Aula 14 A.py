c = 1 
while c < 10:
    print (c)
    c = c+1
print ('FIM')