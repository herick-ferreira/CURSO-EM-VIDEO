lanche = ('Hamburguer', 'Suco', 'Pizza', 'Pudim', 'Batata Frita')

#print(len(lanche))

for cont in range (0, len(lanche)):
    print(lanche[cont])




