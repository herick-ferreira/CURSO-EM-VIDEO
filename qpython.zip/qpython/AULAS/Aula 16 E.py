a = (2, 5, 4)
b = (5, 8, 1, 2)
#c = a + b
c = b + a
#print(c.count(2))
#print(c)
print(c.index(2, 4))