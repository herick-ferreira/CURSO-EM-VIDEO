import random
num = random.randint(1,10)
print(num)