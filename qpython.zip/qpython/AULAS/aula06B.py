n = input('digite algo : ')
print (n.isnumeric ())
