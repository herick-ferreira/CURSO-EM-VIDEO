#print('\033[7;33;44mOlá, Mundo!\033[m')

a = 3
b = 5
print ('Os valores são \033[32m{}\033[m e \033[31;44m{}\033[m!!!'.format(a, b))