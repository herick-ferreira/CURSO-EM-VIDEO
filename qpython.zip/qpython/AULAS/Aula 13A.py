#for c in range (10,0,-1):     
#     print(c)
#print('FIM')

i = int(input ('Início: '))
f = int(input('Fim:'))
p = int(input('Passo: '))
#n = int(input('Digite um número:'))
for c in range (i, f+1, p):
     print(c)
print ('FIM')

