pessoa = ('Gustavo', 39, 'M', 99.88)
del(pessoa)
#del(pessoa[0])
print (pessoa)