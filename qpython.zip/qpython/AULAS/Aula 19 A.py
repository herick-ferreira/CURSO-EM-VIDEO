pessoas = {'nome': 'Gustavo', 'sexo' : 'M', 'idade': 22}
#print(pessoas['nome'])
print(f'O {pessoas["nome"]} tem {pessoas["idade"]} anos.')
