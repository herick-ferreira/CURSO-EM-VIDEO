#help(print)
print(input.__doc__)