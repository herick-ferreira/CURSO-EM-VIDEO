cont = 1
while cont <= 10:
     print(cont,'→',end = '')
     cont += 1
print('Acabou')