galera = [['João',19],['Ana',33],['Joaquim',13],['Maria', 45]] 
print(galera[0][0])