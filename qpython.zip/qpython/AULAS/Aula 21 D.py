#def teste():
#    print(f'Na função teste, n vale {n}')
#    
#n = 2
#print(f'No programa principal n vale {n}')
#teste ()

def teste():
    x = 0
    print(f'Na função teste, n vale {n}')
    print(f'Na função teste, x vale {x}')
n = 2
print(f'No programa principal n vale {n}')
teste ()