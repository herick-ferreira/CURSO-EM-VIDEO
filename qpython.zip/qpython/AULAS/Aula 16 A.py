lanche = ('Hamburguer', 'Suco', 'Pizza', 'Pudim')
for comida in lanche:
     print (f'Eu vou comer {comida}')
print('Comi pra caramba!')