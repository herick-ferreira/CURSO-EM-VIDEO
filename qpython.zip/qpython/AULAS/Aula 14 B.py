n = 1
while n != 0:
   n = int(input('Digite um Valor: '))
print('FIM')