def titulo(txt):
    print ('-='*21)
    print(txt)
    print ('-='*21)
    
titulo('              CURSO EM VÍDEO ')

   