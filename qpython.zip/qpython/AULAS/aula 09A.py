frase = 'Curso em Vídeo Python'
#print (frase.capitalize())
#print (frase.title())

#print(frase.count('o'))
#print(frase.upper ().count('O'))
#print (len(frase))
#print (len(frase.strip()))
#frase = frase.replace('Python','Android')
#print (frase.find ('Vídeo'))
#print(frase.split())
#dividido = frase.split()
#print (dividido[2] [3])