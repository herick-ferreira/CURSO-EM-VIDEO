num = [2, 5, 9, 1]
if 5 in num:
     num.remove(5)
else:
    print('Não achei o número 5')