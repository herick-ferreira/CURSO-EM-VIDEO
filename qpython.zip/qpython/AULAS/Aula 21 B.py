def contador (i, f, p):
      """   
      => Faz uma contagem e mostra na tela.
      :param i: inicio da contagem
      :parem f: fim da contagem
      :parem p: passo da contagem
      :return: sem retorno
      """    
      c = i
      while c <= f:
         print(f'{c}', end =' ')
         c+=p
      print (' FIM')

help(contador)