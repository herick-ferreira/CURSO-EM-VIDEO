a = 4
b = 5
s = a + b
print (s)

a = 8
b = 9
s = a + b
print(s)

# ou

def soma (a,b):
    s = a + b
    print(s)
    

soma(4,5)
soma(8,9)

def soma (a,b):
    print(f'A = {a} e B = {b}')
    s = a + b
    print(f'A soma A + B = {s}')

soma(4,5)
    
soma(b = 4,a = 5)
