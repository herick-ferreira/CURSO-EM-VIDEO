galera = [['João',19],['Ana',33],['Joaquim',13],['Maria', 45]] 
#for p in galera:
#     print(p)
#for p in galera:
#     print(p[1])
for p in galera:
     print(f'{p[0]} tem {p[1]} anos de idade.')