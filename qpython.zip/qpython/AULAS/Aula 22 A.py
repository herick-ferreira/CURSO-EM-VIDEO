import Aula22B

num = int(input('Digite um valor: '))
fat = Aula22B.fatorial(num)
print(f'O fatorial de {num} é {fat}')
print(f'O dobro de {num} é {Aula22B.dobro(num)}')
print(f'O triplo de {num} é {Aula22B.triplo(num)}')
